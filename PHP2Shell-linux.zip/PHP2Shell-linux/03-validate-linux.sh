#!/usr/bin/env bash
# STEP 3 - Validate. Re-runs 01-detect-linux.sh (tag 'validate') and judges the result.
#   sudo ./03-validate-linux.sh        exit code 0 = fixed, 2 = still vulnerable
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="${OUT:-$PWD/php2shell-results}"; export OUT
TAG=validate "$HERE/01-detect-linux.sh" >/dev/null 2>&1
S="$(ls -t "$OUT"/*_validate_*.summary 2>/dev/null | head -n1)"
[ -n "$S" ] || { echo "Detection produced no summary."; exit 1; }
V="${S%.summary}_verdict.txt"; : > "$V"
FAIL=0; WARN=0; REV=0
say() { echo "$*" | tee -a "$V"; }
say "PHP2Shell VALIDATION - $(hostname) - $(date '+%F %T')"; say "Scan: $S"; say ""
while IFS='|' read -r kind a b c d e f g; do
  case "$kind" in
    PHP)    if [ "$f" = yes ]; then [ "$c" != FIXED ] && { WARN=$((WARN+1)); say "[WARN]   old PHP copy on disk: $a ($b) - archive or delete it"; }; continue; fi
            case "$c" in FIXED) say "[PASS]   PHP binary $a is $b";; DISTRO_PACKAGE_CHECK_BELOW) :;; *) FAIL=$((FAIL+1)); say "[FAIL]   PHP binary $a is $b: $c (needs $d)";; esac;;
    LIBPHP) case "$c" in DISTRO_PACKAGE_CHECK_BELOW) :;; FIXED) say "[PASS]   Apache module $a = PHP $b";; *) FAIL=$((FAIL+1)); say "[FAIL]   Apache module $a = PHP $b: $c";; esac;;
    APT)    case "$c" in FIXED) say "[PASS]   package $a $b";; *) FAIL=$((FAIL+1)); say "[FAIL]   package $a $b is below fixed $d - sudo apt update && sudo apt upgrade";; esac;;
    HTTPD)  if [ "$c" = none ]; then WARN=$((WARN+1)); say "[WARN]   httpd pid $a: could not read the loaded PHP library (run with sudo, or PHP is FastCGI)"
            elif [ "$f" = yes ]; then FAIL=$((FAIL+1)); say "[FAIL]   httpd pid $a started BEFORE its PHP library was replaced - restart Apache"
            elif [ "$e" = DISTRO_PACKAGE_CHECK_BELOW ]; then say "[INFO]   running httpd pid $a uses a distro PHP library ($c); judged by the package lines above"
            elif [ "$e" = FIXED ]; then say "[PASS]   running httpd pid $a has loaded $c = PHP $d"
            else FAIL=$((FAIL+1)); say "[FAIL]   running httpd pid $a has loaded $c = PHP $d: $e"; fi;;
    DB3306) [ "$a" = exposed ] && { WARN=$((WARN+1)); say "[WARN]   MariaDB/MySQL listens on all interfaces"; };;
    INDICATOR) case "$a" in
        uploads_php) [ "$b" -gt 0 ] && { REV=$((REV+1)); say "[REVIEW] $b PHP file(s) inside uploads folders - inspect each"; };;
        post_5xx)    [ "$b" -gt 50 ] && { REV=$((REV+1)); say "[REVIEW] $b POST requests ended in HTTP 5xx in the recent log"; };;
        phpinfo_files) [ "$b" -gt 0 ] && { WARN=$((WARN+1)); say "[WARN]   $b phpinfo/test file(s) still in web roots"; };; esac;;
  esac
done < "$S"
say ""
R=FIXED; [ "$FAIL" -gt 0 ] && R="STILL VULNERABLE"
say "RESULT: $R   (fails: $FAIL, warnings: $WARN, review items: $REV)"
[ "$R" = FIXED ] && [ "$REV" -gt 0 ] && say "PHP is patched, but REVIEW items mean you cannot yet say nobody got in: check, rotate secrets, report."
[ "$R" = FIXED ] && [ "$REV" -eq 0 ] && say "Patched and no indicators found by these checks. These checks reduce risk; they do not prove a clean system."
say "Verdict file: $V"
[ "$FAIL" -gt 0 ] && exit 2 || exit 0
