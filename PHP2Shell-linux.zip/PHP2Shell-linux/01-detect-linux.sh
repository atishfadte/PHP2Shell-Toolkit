#!/usr/bin/env bash
# STEP 1 - Detect PHP2Shell (CVE-2026-109618 / CVE-2026-109619) exposure on a Linux server (XAMPP in /opt/lampp and/or distro PHP).
# READ-ONLY. Run with sudo so it can read Apache's loaded libraries and the logs:   sudo ./01-detect-linux.sh
# Writes <host>_<tag>_<time>.txt (report) and .summary (machine-readable, used by 03-validate-linux.sh) into $OUT.
# Fixed upstream versions: 8.2.35, 8.3.36, 8.4.27, 8.5.12. PHP 8.1 and older have no official fix.
#   LAMPP=/opt/lampp   OUT=./php2shell-results   SINCE=2026-08-01   TAG=detect
set -u
LAMPP="${LAMPP:-/opt/lampp}"
OUT="${OUT:-$PWD/php2shell-results}"
SINCE="${SINCE:-2026-08-01}"
TAG="${TAG:-detect}"
HOST="$(hostname)"
STAMP="$(date +%Y%m%d_%H%M%S)"
mkdir -p "$OUT" || { echo "cannot create $OUT"; exit 1; }
REPORT="$OUT/${HOST}_${TAG}_${STAMP}.txt"
SUMMARY="$OUT/${HOST}_${TAG}_${STAMP}.summary"
: > "$REPORT"; : > "$SUMMARY"

log()  { printf '%s\n' "$*" | tee -a "$REPORT"; }
sec()  { log ""; log "========================================================================"; log "$*"; log "========================================================================"; }
rec()  { local IFS='|'; printf '%s\n' "$*" >> "$SUMMARY"; }
IS_ROOT=0; [ "$(id -u)" -eq 0 ] && IS_ROOT=1

# true when a file belongs to an apt package (its version is judged by the package check in section 2, because Ubuntu backports fixes without changing the upstream number)
is_distro() { command -v dpkg >/dev/null 2>&1 && dpkg -S "$1" >/dev/null 2>&1; }

# status for an upstream version string -> "STATUS|required"
php_status() {
  local v="$1" br req=""
  br="$(printf '%s' "$v" | cut -d. -f1,2)"
  case "$br" in 8.5) req=8.5.12;; 8.4) req=8.4.27;; 8.3) req=8.3.36;; 8.2) req=8.2.35;; esac
  if [ -n "$req" ]; then
    if [ "$(printf '%s\n%s\n' "$req" "$v" | sort -V | head -n1)" = "$req" ]; then echo "FIXED|$req"; else echo "VULNERABLE|$req"; fi
  else
    case "$br" in 8.0|8.1|7.*|5.*|4.*) echo "VULNERABLE_NO_OFFICIAL_FIX|move to 8.2.35+/8.3.36+ or a vendor backport";; *) echo "REVIEW|check php.net advisory";; esac
  fi
}

sec "PHP2Shell detection report - $HOST - $(date '+%Y-%m-%d %H:%M:%S')"
log "OS            : $(. /etc/os-release 2>/dev/null; echo "${PRETTY_NAME:-unknown}")"
log "Kernel        : $(uname -r)"
log "Run as root   : $IS_ROOT"
[ "$IS_ROOT" -eq 0 ] && log "WARNING: not root. Loaded-library and log checks will be incomplete. Re-run with sudo."
log "XAMPP path    : $LAMPP $([ -d "$LAMPP" ] && echo '(found)' || echo '(not found)')"
[ -x "$LAMPP/lampp" ] && log "XAMPP version : $("$LAMPP/lampp" version 2>/dev/null | head -n1)"

# ---- 1. PHP binaries ------------------------------------------------------------------------
sec "1. PHP binaries and modules on disk"
OVERALL="NO_PHP_FOUND"; BAD=0; LIVE=0
mapfile -t BINS < <(find / -xdev \( -path /proc -o -path /sys -o -path /snap -o -path '*/node_modules' \) -prune -o -type f \( -name php -o -name 'php[0-9]*' -o -name php-cgi -o -name 'php-fpm*' \) -perm -u+x -print 2>/dev/null | grep -Ev '\.(sh|ini|conf|d)$|/(man|doc|share|include)/' | sort -u)
for b in "${BINS[@]}"; do
  line="$("$b" -v 2>/dev/null | head -n1)"
  ver="$(printf '%s' "$line" | grep -Eo 'PHP [0-9]+\.[0-9]+\.[0-9]+[^ ]*' | head -n1 | cut -d' ' -f2)"
  [ -z "$ver" ] && continue
  backup=no; printf '%s' "$b" | grep -Eiq '(old|bak|backup|\.orig)' && backup=yes
  distro=no; is_distro "$b" && distro=yes; case "$ver" in *ubuntu*|*deb*|*+*) distro=yes;; esac
  upstream="$(printf '%s' "$ver" | grep -Eo '^[0-9]+\.[0-9]+\.[0-9]+')"
  if [ "$distro" = yes ]; then st="DISTRO_PACKAGE_CHECK_BELOW"; req="see section 2"; else IFS='|' read -r st req <<<"$(php_status "$upstream")"; fi
  ini="$("$b" -r 'echo php_ini_loaded_file();' 2>/dev/null)"
  log ""; log "PHP binary : $b"
  log "  version  : $ver    status: $st    needs: $req    backup copy: $backup"
  log "  php.ini  : ${ini:-none}"
  rec PHP "$b" "$ver" "$st" "$req" "$ini" "$backup"
  if [ "$backup" = no ]; then LIVE=$((LIVE+1)); [ "$st" != FIXED ] && [ "$distro" = no ] && BAD=$((BAD+1)); fi
done
[ "${#BINS[@]}" -eq 0 ] && log "  (no php executables found)"

mapfile -t LIBS < <(find / -xdev \( -path /proc -o -path /sys -o -path /snap \) -prune -o -type f -name 'libphp*.so' -print 2>/dev/null | sort -u)
for l in "${LIBS[@]}"; do
  lv="$(grep -a -o 'X-Powered-By: PHP/[0-9][0-9.]*' "$l" 2>/dev/null | head -n1 | sed 's|.*PHP/||')"
  lm="$(stat -c %Y "$l")"
  IFS='|' read -r lst lreq <<<"$(php_status "${lv:-0.0.0}")"
  is_distro "$l" && lst=DISTRO_PACKAGE_CHECK_BELOW
  log "Apache module: $l  PHP ${lv:-unknown} (from library string)  status: $lst  modified: $(date -d @"$lm" '+%F %T')"
  rec LIBPHP "$l" "${lv:-unknown}" "$lst" "$lm"
  printf '%s' "$l" | grep -Eiq '(old|bak|backup)' || { LIVE=$((LIVE+1)); [ "$lst" != FIXED ] && [ "$lst" != DISTRO_PACKAGE_CHECK_BELOW ] && BAD=$((BAD+1)); }
done

# ---- 2. distro packages ---------------------------------------------------------------------
sec "2. Distribution PHP packages (apt)"
if command -v dpkg >/dev/null 2>&1; then
  . /etc/os-release 2>/dev/null
  case "${VERSION_ID:-}" in 26.04) FIXPKG="php8.5 8.5.4-0ubuntu1.5";; 24.04) FIXPKG="php8.3 8.3.6-0ubuntu0.24.04.13";; 22.04) FIXPKG="php8.1 8.1.2-1ubuntu2.28";; *) FIXPKG="";; esac
  PK="$(dpkg-query -W -f='${Package} ${Version} ${Status}\n' 'php*' 2>/dev/null | awk '$NF=="installed"{print $1" "$2}' | grep -E '^(php[0-9.]*-(cli|fpm|cgi|common)|libapache2-mod-php[0-9.]*|php[0-9.]*) ' )"
  if [ -z "$PK" ]; then log "  no php packages installed through apt."
  else
    echo "$PK" | sed 's/^/  /' | tee -a "$REPORT"
    if [ -n "$FIXPKG" ]; then
      set -- $FIXPKG; fpk="$1"; fver="$2"
      log "  Ubuntu ${VERSION_ID} fixed version (USN-8948-1, per a third-party summary - confirm at ubuntu.com/security): $fpk $fver"
      while read -r name ver; do
        [ -z "$name" ] && continue
        case "$name" in ${fpk}-*|libapache2-mod-${fpk}|${fpk}) if dpkg --compare-versions "$ver" ge "$fver"; then s=FIXED; else s=VULNERABLE; BAD=$((BAD+1)); fi; log "  $name $ver -> $s"; rec APT "$name" "$ver" "$s" "$fver";; esac
      done <<<"$PK"
    else log "  No fixed-version table for this Ubuntu release in this script. Run: apt list --upgradable | grep -i php"; fi
  fi
else log "  dpkg not available (not a Debian/Ubuntu system)."; fi

# ---- 3. running Apache / PHP-FPM ------------------------------------------------------------
sec "3. Running web processes and the PHP library each one actually has loaded"
NOW="$(date +%s)"
mapfile -t HPIDS < <(pgrep -x httpd 2>/dev/null; pgrep -x apache2 2>/dev/null)
if [ "${#HPIDS[@]}" -eq 0 ]; then log "  No httpd/apache2 process running."; fi
declare -A SEEN
for pid in "${HPIDS[@]}"; do
  [ -z "$pid" ] && continue
  exe="$(readlink "/proc/$pid/exe" 2>/dev/null)"; et="$(ps -o etimes= -p "$pid" 2>/dev/null | tr -d ' ')"
  lib="$(grep -ao '/[^ ]*libphp[^ ]*\.so' "/proc/$pid/maps" 2>/dev/null | head -n1)"
  key="$exe|$lib"; [ -n "${SEEN[$key]:-}" ] && continue; SEEN[$key]=1
  if [ -z "$lib" ]; then
    log "  pid $pid ($exe): no libphp in memory map $([ "$IS_ROOT" -eq 0 ] && echo '(need sudo to read it)' || echo '(PHP via FastCGI/PHP-FPM, or not loaded yet)')"
    rec HTTPD "$pid" "${et:-?}" "none" "unknown" "unknown" "unknown"; continue
  fi
  lv="$(grep -a -o 'X-Powered-By: PHP/[0-9][0-9.]*' "$lib" 2>/dev/null | head -n1 | sed 's|.*PHP/||')"
  IFS='|' read -r lst lreq <<<"$(php_status "${lv:-0.0.0}")"
  is_distro "$lib" && lst=DISTRO_PACKAGE_CHECK_BELOW
  lm="$(stat -c %Y "$lib" 2>/dev/null || echo 0)"; stale=no
  [ -n "$et" ] && [ $((NOW - et)) -lt "$lm" ] && stale=yes
  log "  pid $pid ($exe) up ${et:-?}s loaded $lib = PHP ${lv:-unknown} -> $lst$([ "$stale" = yes ] && echo '   ** library file is NEWER than this process: Apache was NOT restarted after the update **')"
  rec HTTPD "$pid" "${et:-?}" "$lib" "${lv:-unknown}" "$lst" "$stale"
done
log ""; log "PHP-FPM / php-cgi processes:"
ps -eo pid,user,etimes,cmd 2>/dev/null | grep -E 'php-fpm|php-cgi' | grep -v grep | sed 's/^/  /' | tee -a "$REPORT"

# ---- 4. configuration -----------------------------------------------------------------------
sec "4. PHP settings and Apache directives that matter"
if [ -x "$LAMPP/bin/php" ]; then
  "$LAMPP/bin/php" -r 'foreach(["session.upload_progress.enabled","fatal_error_backtraces","memory_limit","post_max_size","upload_max_filesize","expose_php","display_errors","allow_url_include","disable_functions"] as $k){echo "  $k = ",var_export(ini_get($k),true),"\n";}' 2>/dev/null | tee -a "$REPORT"
  rec SETTING "$("$LAMPP/bin/php" -r 'echo ini_get("session.upload_progress.enabled");' 2>/dev/null)" "$("$LAMPP/bin/php" -r 'echo ini_get("memory_limit");' 2>/dev/null)"
fi
for f in "$LAMPP/etc/httpd.conf" "$LAMPP"/etc/extra/*.conf /etc/apache2/apache2.conf /etc/apache2/mods-enabled/php*.load; do
  [ -f "$f" ] && grep -nEH '^\s*(LoadModule\s+php|PHPIniDir|LimitRequestBody|Include.*php2shell|SetHandler.*php|AddType.*php)' "$f" 2>/dev/null | sed 's/^/  /' | tee -a "$REPORT"
done

# ---- 5. network ------------------------------------------------------------------------------
sec "5. Listening ports of interest"
if command -v ss >/dev/null 2>&1; then
  ss -ltnp 2>/dev/null | awk 'NR==1 || $4 ~ /:(21|22|80|443|3306|8080|8443)$/' | sed 's/^/  /' | tee -a "$REPORT"
  if ss -ltn 2>/dev/null | awk '$4 ~ /(^0\.0\.0\.0|^\*|^\[::\]):3306$/' | grep -q .; then log "WARNING: MariaDB/MySQL (3306) listens on all interfaces. Bind it to 127.0.0.1 unless remote access is needed."; rec DB3306 exposed; else rec DB3306 ok; fi
fi

# ---- 6. sites + indicators -------------------------------------------------------------------
sec "6. Web roots, WordPress, and indicators of compromise (since $SINCE)"
DOCROOTS=()
[ -d "$LAMPP/htdocs" ] && DOCROOTS+=("$LAMPP/htdocs")
for f in "$LAMPP/etc/httpd.conf" "$LAMPP"/etc/extra/*.conf /etc/apache2/sites-enabled/*.conf; do
  [ -f "$f" ] || continue
  while read -r d; do d="${d//\"/}"; [ -d "$d" ] && DOCROOTS+=("$d"); done < <(awk 'tolower($1)=="documentroot"{print $2}' "$f" 2>/dev/null)
done
[ -d /var/www/html ] && DOCROOTS+=(/var/www/html)
mapfile -t DOCROOTS < <(printf '%s\n' "${DOCROOTS[@]}" | sort -u)
log "Document roots:"; for d in "${DOCROOTS[@]}"; do log "  $d"; done
log "WordPress installs:"
for d in "${DOCROOTS[@]}"; do find "$d" -maxdepth 4 -name wp-config.php 2>/dev/null; done | while read -r w; do
  s="$(dirname "$w")"; v="$(grep -Eo "wp_version = '[^']+'" "$s/wp-includes/version.php" 2>/dev/null | cut -d"'" -f2)"; log "  $s  [WordPress ${v:-?}]"; rec WORDPRESS "$s" "${v:-?}"; done
UP=0; RC=0; INFO=0
for d in "${DOCROOTS[@]}"; do
  n="$(find "$d" -path '*/uploads/*' \( -name '*.php' -o -name '*.phtml' -o -name '*.phar' \) 2>/dev/null | tee -a "$OUT/.up_$$" | wc -l)"; UP=$((UP+n))
  n="$(find "$d" -type f \( -name '*.php' -o -name '*.phtml' -o -name '*.phar' \) -newermt "$SINCE" 2>/dev/null | wc -l)"; RC=$((RC+n))
  n="$(find "$d" -maxdepth 3 -type f \( -iname 'phpinfo*.php' -o -iname 'info.php' -o -iname 'test.php' -o -iname 'pi.php' \) 2>/dev/null | tee -a "$OUT/.info_$$" | wc -l)"; INFO=$((INFO+n))
done
log ""; log "PHP files inside .../uploads/ (should normally be 0): $UP"; [ -f "$OUT/.up_$$" ] && head -n 25 "$OUT/.up_$$" | sed 's/^/    /' | tee -a "$REPORT"
log "phpinfo/test files left in web roots (delete them): $INFO"; [ -f "$OUT/.info_$$" ] && sed 's/^/    /' "$OUT/.info_$$" | tee -a "$REPORT"
log "PHP files modified since $SINCE: $RC  (expect plugin/theme updates; newest 30 below)"
for d in "${DOCROOTS[@]}"; do find "$d" -type f \( -name '*.php' -o -name '*.phtml' \) -newermt "$SINCE" -printf '%TY-%Tm-%Td %TH:%TM  %p\n' 2>/dev/null; done | sort -r | head -n 30 | sed 's/^/    /' | tee -a "$REPORT"
rm -f "$OUT/.up_$$" "$OUT/.info_$$"
P5=0
for lg in "$LAMPP/logs/access_log" /var/log/apache2/access.log; do
  [ -r "$lg" ] || continue
  n="$(tail -n 200000 "$lg" | awk '$6=="\"POST" && $9 ~ /^5/ {c++} END{print c+0}')"; P5=$((P5+n))
  log "5xx POST in last 200000 lines of $lg: $n"
  tail -n 200000 "$lg" | awk '$6=="\"POST" && $9 ~ /^5/ {c[$1]++} END{for(i in c) print c[i], i}' | sort -rn | head -n 5 | sed 's/^/    top client: /' | tee -a "$REPORT"
done
log ""; log "Accounts with UID 0 besides root:"; awk -F: '$3==0 && $1!="root"{print "  "$1}' /etc/passwd | tee -a "$REPORT"
log "authorized_keys files modified since $SINCE:"; find /root /home -maxdepth 3 -name authorized_keys -newermt "$SINCE" 2>/dev/null | sed 's/^/  /' | tee -a "$REPORT"
log "cron / systemd units changed since $SINCE:"; find /etc/cron* /var/spool/cron /etc/systemd/system -type f -newermt "$SINCE" 2>/dev/null | sed 's/^/  /' | tee -a "$REPORT"
rec INDICATOR uploads_php "$UP"; rec INDICATOR recent_php "$RC"; rec INDICATOR phpinfo_files "$INFO"; rec INDICATOR post_5xx "$P5"

# ---- 7. verdict ------------------------------------------------------------------------------
sec "7. SUMMARY"
if [ "$LIVE" -gt 0 ] || grep -q '^APT|' "$SUMMARY"; then OVERALL=FIXED; fi
[ "$BAD" -gt 0 ] && OVERALL=ACTION_REQUIRED
grep -q '^HTTPD|.*|yes$' "$SUMMARY" && OVERALL=ACTION_REQUIRED
awk -F'|' '$1=="HTTPD" && $6 ~ /VULNERABLE|REVIEW/ {f=1} END{exit !f}' "$SUMMARY" && OVERALL=ACTION_REQUIRED
rec OVERALL "$OVERALL"
log "OVERALL: $OVERALL"
[ "$OVERALL" = ACTION_REQUIRED ] && log "Next: sudo ./02-interim-fix-linux.sh  (quick protection), then patch PHP (README-linux.md)."
{ [ "$UP" -gt 0 ] || [ "$P5" -gt 50 ]; } && log "REVIEW: PHP in uploads and/or many 5xx POSTs - possible earlier compromise."
[ "$INFO" -gt 0 ] && log "NOTE: phpinfo/test files are exposed; remove them (02-interim-fix-linux.sh --remove-phpinfo moves them aside)."
log "Report : $REPORT"; log "Summary: $SUMMARY"
