# PHP2Shell toolkit for Linux (XAMPP in /opt/lampp, Ubuntu)

Fixed upstream PHP: **8.2.35, 8.3.36, 8.4.27, 8.5.12**. PHP 8.1 and older have no official fix.
XAMPP for Linux 8.2.12 ships PHP 8.2.12 (built Nov 2023): **vulnerable**.
Ubuntu's own `php` package is a separate copy and does not update XAMPP's PHP.

## 0. Do this first, right now
```bash
sudo rm /opt/lampp/htdocs/phpinfo.php      # the test file you created: it exposes your configuration to anyone
```

## Copy the toolkit to the server (IAP SSH)
```bash
gcloud compute scp --tunnel-through-iap PHP2Shell-linux.zip <instance>:~ --zone <zone>
# on the server:
unzip PHP2Shell-linux.zip && cd PHP2Shell-linux && chmod +x *.sh
```
(or paste the three `.sh` files with `nano`).

## Steps
| Step | Command | What it does |
| --- | --- | --- |
| 1 | `sudo ./01-detect-linux.sh` | Read-only. Finds every PHP binary and Apache module, reads the PHP library the RUNNING Apache has loaded and whether Apache was restarted since the file changed, checks apt PHP packages against the Ubuntu fixed versions, php.ini and Apache directives, ports, WordPress sites, PHP files in uploads, leftover phpinfo files, 5xx POST bursts, extra UID-0 users, changed cron/systemd/authorized_keys. Output goes to `./php2shell-results/` (`.txt` report and `.summary`). |
| 2 | `sudo ./02-interim-fix-linux.sh --remove-phpinfo` | Quick protection, not a patch: `session.upload_progress.enabled=0`, `fatal_error_backtraces=0` (8.5 only), lowers `post_max_size`/`upload_max_filesize` only if above 32M/16M, adds Apache `LimitRequestBody`, tests the config, restarts Apache, restores backups if the test fails. Try `--dry-run` first. |
| 3 | patch PHP (below) | The actual fix. |
| 4 | `sudo ./03-validate-linux.sh` | PASS/FAIL. Exit code 0 = fixed, 2 = still vulnerable. Fails if Apache's loaded PHP is unfixed or Apache was not restarted after the update. |

## Step 3: how to actually patch
**Option A (recommended): move the sites from XAMPP to Ubuntu's own Apache + PHP.** Ubuntu 26.04 gets PHP fixes through `apt`, so the next one takes minutes. Ubuntu's fixed package is `php8.5` 8.5.4-0ubuntu1.5 (from a third-party summary of USN-8948-1: confirm at ubuntu.com/security before relying on it). PHP 8.5 is a big jump from 8.2, so test every site on a copy first.
1. Back up everything: `sudo tar czf ~/lampp-backup-$(date +%F).tgz /opt/lampp` and the databases: `sudo /opt/lampp/bin/mysqldump -u root -p --all-databases > ~/all-dbs.sql`.
2. Install: `sudo apt update && sudo apt install apache2 libapache2-mod-php8.5 php8.5-mysql php8.5-curl php8.5-gd php8.5-mbstring php8.5-xml php8.5-zip php8.5-intl mariadb-server`. Check the package names with `apt search php8.5`.
3. Stop XAMPP so it frees port 80: `sudo /opt/lampp/lampp stop`.
4. Copy each site from `/opt/lampp/htdocs/<site>` to `/var/www/<site>`, `sudo chown -R www-data:www-data` it, create an Apache virtual host, enable it (`a2ensite`), import the database, and update the DB host/credentials in `wp-config.php`.
5. Test, then `sudo systemctl enable apache2 mariadb`, and turn on automatic security updates: `sudo apt install unattended-upgrades`.
6. Run `sudo ./03-validate-linux.sh`.

**Option B: a fixed XAMPP build.** I could not confirm that Apache Friends has published an XAMPP for Linux with PHP 8.2.35 or newer; check apachefriends.org. If one exists: back up `/opt/lampp` and the databases, run `sudo /opt/lampp/lampp stop`, then run the new installer. Expect it to be the same manual upgrade for each later PHP release.

**Not recommended:** compiling PHP yourself for XAMPP's Apache. It is fragile and you would own every later security update.

## After patching
* Run step 4. Then work through the compromise checks (section 5 of the response guide): the 01 report lists PHP files in uploads, files changed since 1 Aug 2026, odd UID-0 users, cron/systemd and authorized_keys changes. If anything looks wrong, rotate DB passwords, WordPress salts, SSH keys and API keys.
* Harden XAMPP defaults while it is still in use: `sudo /opt/lampp/lampp security` (sets passwords for MySQL, phpMyAdmin and FTP, and restricts phpMyAdmin).
* Keep MariaDB on `127.0.0.1` only, and keep phpMyAdmin off the public internet.

## Limits
* Tested here on a mock XAMPP tree (detect, dry run, real run, validate before and after), not on a real XAMPP server. Run on one server first.
* Version detection for `libphp*.so` reads the `X-Powered-By: PHP/x.y.z` string inside the file, which is best effort.
* PHP-FPM setups and several PHP copies are listed but the "running" check is strongest for Apache with mod_php (the XAMPP default).
* A PASS means the vulnerable code is gone and common indicators were not found. It does not prove a server is clean.
