#!/usr/bin/env bash
# STEP 2 - INTERIM protection for PHP2Shell on XAMPP for Linux. This is NOT the patch: it only blocks the attack paths PHP has confirmed.
#   sudo ./02-interim-fix-linux.sh [--dry-run] [--remove-phpinfo] [--limit-bytes N]
# Backs up php.ini and httpd.conf, sets:
#   session.upload_progress.enabled=0, fatal_error_backtraces=0 (PHP 8.5 only), post_max_size<=32M, upload_max_filesize<=16M (only lowered, never raised)
#   Apache LimitRequestBody (default 33554432 = 32 MB; raise it if your sites accept larger uploads)
# Tests the Apache config, restarts Apache via 'lampp restartapache', and restores the backups if the config test fails.
# --remove-phpinfo moves phpinfo*.php / info.php / test.php out of the web root into a backup folder (moved, not deleted).
set -u
LAMPP="${LAMPP:-/opt/lampp}"
LIMIT=33554432; DRY=0; RMINFO=0
while [ $# -gt 0 ]; do case "$1" in --dry-run) DRY=1;; --remove-phpinfo) RMINFO=1;; --limit-bytes) shift; LIMIT="${1:?number needed}";; *) echo "unknown option $1"; exit 1;; esac; shift; done
[ "$(id -u)" -eq 0 ] || { echo "Run with sudo."; exit 1; }
PHP="$LAMPP/bin/php"; INI="$LAMPP/etc/php.ini"; CONF="$LAMPP/etc/httpd.conf"; EXTRA="$LAMPP/etc/extra/php2shell-hardening.conf"
[ -x "$PHP" ] && [ -f "$INI" ] && [ -f "$CONF" ] || { echo "XAMPP files not found under $LAMPP (set LAMPP=...)"; exit 1; }
STAMP="$(date +%Y%m%d_%H%M%S)"; BK="$LAMPP/php2shell_backup_$STAMP"
BRANCH="$("$PHP" -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')"
run() { if [ "$DRY" -eq 1 ]; then echo "  [dry-run] $*"; else "$@"; fi; }
to_bytes() { local s="${1//[[:space:]]/}"; local n="${s%%[!0-9-]*}" u="${s##*[0-9]}"; [ -z "$n" ] && { echo 0; return; }
  case "${u^^}" in K) echo $((n*1024));; M) echo $((n*1048576));; G) echo $((n*1073741824));; *) echo "$n";; esac; }
set_ini() { # name value [lower]
  local name="$1" val="$2" lower="${3:-}" esc="${1//./\\.}" cur
  cur="$(grep -E "^[[:space:]]*${esc}[[:space:]]*=" "$INI" | tail -n1 | cut -d= -f2- | sed 's/[;#].*//; s/^[[:space:]]*//; s/[[:space:]]*$//')"
  if [ "$lower" = lower ] && [ -n "$cur" ] && [ "$(to_bytes "$cur")" -gt 0 ] && [ "$(to_bytes "$cur")" -le "$(to_bytes "$val")" ]; then echo "  keep  $name = $cur (already <= $val)"; return; fi
  if [ "$DRY" -eq 1 ]; then echo "  [dry-run] set $name = $val (was: ${cur:-unset})"; return; fi
  if grep -qE "^[[:space:]]*${esc}[[:space:]]*=" "$INI"; then sed -i -E "s|^[[:space:]]*${esc}[[:space:]]*=.*|${name} = ${val}|" "$INI"; else printf '\n%s = %s\n' "$name" "$val" >> "$INI"; fi
  echo "  set   $name = $val (was: ${cur:-unset})"
}
echo "PHP $("$PHP" -r 'echo PHP_VERSION;') (branch $BRANCH), ini $INI"
run mkdir -p "$BK"; run cp -p "$INI" "$BK/php.ini"; run cp -p "$CONF" "$BK/httpd.conf"
echo "Backups in $BK"
echo "PHP settings:"
set_ini session.upload_progress.enabled 0
[ "$BRANCH" = "8.5" ] && set_ini fatal_error_backtraces 0
set_ini post_max_size 32M lower
set_ini upload_max_filesize 16M lower
echo "Apache: LimitRequestBody $LIMIT"
if [ "$DRY" -eq 0 ]; then
  printf '# Added for PHP2Shell interim protection - remove after PHP is patched and tested\nLimitRequestBody %s\n' "$LIMIT" > "$EXTRA"
  grep -q 'php2shell-hardening.conf' "$CONF" || printf '\nInclude "%s"\n' "$EXTRA" >> "$CONF"
  if ! "$LAMPP/bin/apachectl" -t 2>&1 | tee /dev/stderr | grep -q 'Syntax OK'; then
    echo "Apache config test FAILED - restoring backups."; cp -p "$BK/php.ini" "$INI"; cp -p "$BK/httpd.conf" "$CONF"; rm -f "$EXTRA"; exit 1
  fi
fi
if [ "$RMINFO" -eq 1 ]; then
  echo "Moving phpinfo/test files out of the web root:"
  find "$LAMPP/htdocs" -maxdepth 3 -type f \( -iname 'phpinfo*.php' -o -iname 'info.php' -o -iname 'test.php' -o -iname 'pi.php' \) 2>/dev/null | while read -r f; do
    echo "  $f -> $BK/removed/"; run mkdir -p "$BK/removed"; run mv "$f" "$BK/removed/$(echo "$f" | tr '/' '_')"; done
fi
echo "Restarting Apache..."
run "$LAMPP/lampp" restartapache
echo
echo "DONE (interim). The server is STILL VULNERABLE until PHP itself is patched (README-linux.md)."
echo "Undo: cp $BK/php.ini $INI; cp $BK/httpd.conf $CONF; rm -f $EXTRA; $LAMPP/lampp restartapache"
