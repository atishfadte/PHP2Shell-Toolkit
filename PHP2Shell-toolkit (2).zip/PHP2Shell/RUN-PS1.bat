@echo off
rem Generic launcher: runs any .ps1 with the execution policy bypassed, as administrator.
rem Usage:  RUN-PS1.bat <script.ps1> [arguments]      (you can also drag a .ps1 file onto this file)
rem NOTE: written without ( ) blocks on purpose, so folder names like "toolkit (1)" work.
setlocal

net session >nul 2>&1
if %errorlevel% equ 0 goto elevated

echo Asking for administrator rights...
set "SELF=%~f0"
set "ARGS=%*"
powershell -NoProfile -Command "Start-Process -FilePath $env:SELF -ArgumentList $env:ARGS -Verb RunAs"
exit /b

:elevated
if "%~1"=="" goto usage
set "SCRIPT=%~1"
shift
set "REST="

:collect
if "%~1"=="" goto run
set REST=%REST% "%~1"
shift
goto collect

:run
set "HERE=%~dp0"
powershell -NoProfile -Command "Get-ChildItem -LiteralPath $env:HERE -Recurse -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue"
if exist "C:\PHP2Shell\fix" powershell -NoProfile -Command "Get-ChildItem -LiteralPath 'C:\PHP2Shell\fix' -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue"

cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" %REST%
set "RC=%errorlevel%"
echo.
echo Finished with exit code %RC%.
pause
exit /b %RC%

:usage
echo Usage: RUN-PS1.bat script.ps1 [arguments]
pause
exit /b 1
