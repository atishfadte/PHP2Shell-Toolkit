@echo off
rem STEP 2 - generate fix scripts from the NEWEST detect result in C:\PHP2Shell\results.
rem Or pass a specific result file:  RUN-02-Generate-Fixes.bat C:\PHP2Shell\results\WEB01_detect_20261022_160000.json
setlocal
set "J=%~1"
if defined J goto go
for /f "delims=" %%F in ('dir /b /o-d "C:\PHP2Shell\results\*_detect_*.json" 2^>nul') do if not defined J set "J=C:\PHP2Shell\results\%%F"
if not defined J goto none
:go
echo Using result file: %J%
call "%~dp0RUN-PS1.bat" "%~dp002-Generate-Fixes.ps1" -ResultFile "%J%"
exit /b
:none
echo No detect result found in C:\PHP2Shell\results - run RUN-01-Detect.bat first.
pause
exit /b 1
