@echo off
rem STEP 3 - validate that the server is fixed.
rem Optional: probe a site as well:   RUN-03-Validate.bat -Url https://your-site.goa.gov.in
call "%~dp0RUN-PS1.bat" "%~dp003-Validate.ps1" %*
