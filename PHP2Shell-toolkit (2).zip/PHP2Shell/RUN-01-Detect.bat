@echo off
rem STEP 1 - detect. Double-click this file. Add /fast after the file name to search only common folders.
if /i "%~1"=="/fast" goto fast
call "%~dp0RUN-PS1.bat" "%~dp001-Detect-PHP2Shell.ps1"
exit /b
:fast
call "%~dp0RUN-PS1.bat" "%~dp001-Detect-PHP2Shell.ps1" -Fast
exit /b
